## Must-b PDF Brain

RAG (Retrieval-Augmented Generation) tabanlı döküman işleme motoru.

### Özellikler
- PDF, DOCX, TXT, MD formatları desteklenir
- Akıllı chunking (paragraph, sentence, semantic)
- pgvector veya Pinecone ile vektör depolama
- Citation-backed yanıtlar (hangi sayfadan alındığı gösterilir)
- Batch ingestion: 1000+ dosya paralel işlenir