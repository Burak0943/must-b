## Must-b ElevenLabs Voice AI

ElevenLabs text-to-speech API ile ses sentezler ve klonlama yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- ElevenLabs hesabı ve API erişimi
- Must-b Core v1.2+