## Must-b Firebase Admin Bridge

Firestore, Auth ve Storage'ı ajan kontrolüyle yönetir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Firebase hesabı ve API erişimi
- Must-b Core v1.2+