## Must-b HashiCorp Vault Secrets

Vault secret engine'lerden gizli bilgileri çeker ve döndürür.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Vault hesabı ve API erişimi
- Must-b Core v1.2+