## Must-b Tavily Research Agent

Tavily AI araştırma API'siyle derinlemesine web araştırması yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Tavily hesabı ve API erişimi
- Must-b Core v1.2+