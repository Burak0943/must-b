## Must-b Together AI Gateway

Together AI üzerindeki açık kaynak LLM'lere inference gönderir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Together AI hesabı ve API erişimi
- Must-b Core v1.2+