## Must-b PostHog Product Analytics

PostHog feature flag ve event'larını ajan akışına entegre eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- PostHog hesabı ve API erişimi
- Must-b Core v1.2+