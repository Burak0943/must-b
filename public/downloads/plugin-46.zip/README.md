## Must-b Cloud Cost Optimizer

AWS ve GCP kaynaklarının maliyet analizini yapar ve tasarruf önerir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Cloud hesabı ve API erişimi
- Must-b Core v1.2+