## Must-b Segment Analytics

Segment track/identify/group event'larını ajan görevlerinden tetikler.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Segment hesabı ve API erişimi
- Must-b Core v1.2+