## Must-b Resend Email API

Resend API ile React Email şablonlarını render edip gönderir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Resend hesabı ve API erişimi
- Must-b Core v1.2+