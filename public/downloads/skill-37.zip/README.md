## Must-b Intercom Live Assist

Intercom konuşmalarına ajan yanıtları ekler ve otomatik segmentasyon yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Intercom hesabı ve API erişimi
- Must-b Core v1.2+