## Must-b Python Code Executor

Sandbox Python ortamında kod çalıştırır, paket kurar ve sonuç döndürür.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Python hesabı ve API erişimi
- Must-b Core v1.2+