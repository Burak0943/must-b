## Must-b File System Explorer

Dosya sistemi üzerinde okuma, yazma, taşıma ve arama işlemleri yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Native hesabı ve API erişimi
- Must-b Core v1.2+