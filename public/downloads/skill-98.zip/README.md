## Must-b SerpAPI Search Engine

Google, Bing ve diğer arama motorlarından yapılandırılmış sonuç çeker.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- SerpAPI hesabı ve API erişimi
- Must-b Core v1.2+