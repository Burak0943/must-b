## Must-b Mixpanel Event Tracker

Mixpanel event ve funnel analizlerini ajan karar süreçlerine dahil eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Mixpanel hesabı ve API erişimi
- Must-b Core v1.2+