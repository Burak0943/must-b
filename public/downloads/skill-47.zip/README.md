## Must-b Neon Serverless Postgres

Neon branching ve serverless Postgres endpoint'lerini yönetir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Neon hesabı ve API erişimi
- Must-b Core v1.2+