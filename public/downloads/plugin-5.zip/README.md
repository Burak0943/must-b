## Must-b VS Code Bridge

Must-b'nin en çok indirilen plugin'i. VS Code Language Server Protocol (LSP) ve Extension API üzerinden derin IDE entegrasyonu.

### Özellikler
- Dosya açma, düzenleme, kaydetme
- Diagnostics (lint hatalarını okur ve düzeltir)
- Terminal entegrasyonu (VS Code integrated terminal)
- Extension çalıştırma (Prettier, ESLint otomatik format)
- Diff görüntüleme ve merge conflict çözümü
- Multi-root workspace desteği