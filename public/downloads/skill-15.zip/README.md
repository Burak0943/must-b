## Must-b Jira Project Automator

Jira REST API v3 üzerinden proje yönetimi otomasyonu.

### Özellikler
- Issue oluşturma, güncelleme, geçiş (transition)
- Backlog'dan sprint atama
- Epic ve story hiyerarşisi yönetimi
- JQL sorguları ile raporlama