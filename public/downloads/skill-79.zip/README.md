## Must-b Chroma DB Manager

Chroma embeding collection'larını yönetir ve similarity search çalıştırır.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Chroma hesabı ve API erişimi
- Must-b Core v1.2+