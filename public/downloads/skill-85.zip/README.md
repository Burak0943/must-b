## Must-b Groq LLM Inference

Groq'un ultra-hızlı inference API'sini Must-b pipeline'ına bağlar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Groq hesabı ve API erişimi
- Must-b Core v1.2+