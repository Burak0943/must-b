## Must-b SSH Remote Connector

Uzak sunuculara SSH bağlanır, komut çalıştırır ve dosya transfer eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- SSH hesabı ve API erişimi
- Must-b Core v1.2+