## Must-b OpenAI Orchestrator

Must-b'nin birincil LLM köprüsü. OpenAI API'nin tüm endpoint'lerini Must-b ajan pipeline'ına entegre eder. Akıllı model seçimi, token yönetimi ve multi-turn konuşma hafızası içerir.

### Özellikler
- **Akıllı Model Seçimi**: Görev karmaşıklığına göre GPT-4o vs GPT-4o-mini otomatik seçimi
- **Token Optimizasyonu**: Konteks penceresini aşan konuşmalar için akıllı summarization
- **Rate Limit Yönetimi**: Otomatik retry ve exponential backoff
- **Streaming**: Real-time token streaming desteği
- **Embeddings**: text-embedding-3-large ile semantic search

### Desteklenen Modeller
- gpt-4o, gpt-4o-mini
- gpt-4-turbo
- text-embedding-3-large, text-embedding-3-small
- dall-e-3 (görsel görevler için)

### Gereksinimler
- OpenAI API Key
- Organization ID (isteğe bağlı)