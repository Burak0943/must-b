## Must-b Zapier Workflow Engine

Zapier Zap'larını programatik olarak tetikler ve veri geçişi yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Zapier hesabı ve API erişimi
- Must-b Core v1.2+