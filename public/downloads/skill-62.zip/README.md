## Must-b GitHub Actions Trigger

GitHub Actions workflow'larını tetikler ve run sonuçlarını takip eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- GitHub hesabı ve API erişimi
- Must-b Core v1.2+