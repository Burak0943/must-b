## Must-b LogRocket Session Replay

LogRocket oturum replay'lerini analiz eder ve hata raporlar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- LogRocket hesabı ve API erişimi
- Must-b Core v1.2+