## Must-b Cloudflare Workers Deploy

Cloudflare Workers ve Pages projelerini otomatik push eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Cloudflare hesabı ve API erişimi
- Must-b Core v1.2+