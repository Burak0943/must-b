## Must-b Clerk Auth Integration

Clerk oturum yönetimi ve organizasyon yapısını kontrol eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Clerk hesabı ve API erişimi
- Must-b Core v1.2+