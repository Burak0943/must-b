## Must-b WhatsApp Business Bridge

Meta WhatsApp Business Cloud API entegrasyonu.

### Özellikler
- Gelen mesajları sınıflandırır (sorgu, şikayet, sipariş vb.)
- Template message gönderimi
- Media (resim, PDF, ses) işleme
- Human handoff: Belirli durumlarda insan desteğine yönlendirme