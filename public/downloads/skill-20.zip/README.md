## Must-b Terminal Executor

Must-b'nin temel OS kontrol katmanı. Güvenli, denetlenmiş shell command execution.

### Özellikler
- Allowlist tabanlı komut filtreleme
- Her komut için audit log (timestamp, çıktı, exit code)
- Timeout ve resource limit (CPU, memory) desteği
- Root koruması: `sudo` komutları varsayılan olarak engellenir

### Desteklenen Shell'ler
- bash, zsh, fish (Linux/macOS)
- PowerShell 7, cmd (Windows)