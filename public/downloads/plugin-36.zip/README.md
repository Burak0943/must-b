## Must-b Queue Manager (BullMQ)

BullMQ ile görev kuyruğu oluşturur, priority ve retry yönetir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- BullMQ hesabı ve API erişimi
- Must-b Core v1.2+