## Must-b Salesforce Integration

Salesforce Object'lerini okur, yazar ve Apex trigger'larını çalıştırır.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Salesforce hesabı ve API erişimi
- Must-b Core v1.2+