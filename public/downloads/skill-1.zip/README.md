## Must-b Stripe Billing Agent

Bu skill, Stripe Billing API'yi Must-b ajan çerçevesine tam entegre eder. Ajan, Stripe webhook event'larını (invoice.payment_failed, customer.subscription.updated vb.) gerçek zamanlı olarak dinler ve iş kurallarınıza göre otomatik aksiyon alır.

### Özellikler
- **Webhook İmzalama**: Tüm Stripe webhook'ları `stripe-signature` header'ı ile doğrulanır.
- **Otomatik Retry**: Başarısız ödemeler için exponential backoff ile 3 deneme yapılır.
- **Churn Tahmini**: Son 30 günlük ödeme geçmişine dayanarak churn riski skorlar.
- **Dashboard**: Stripe Dashboard'a yazılabilir metadata ile zenginleştirilmiş müşteri profilleri.

### Desteklenen Stripe API'ler
- `stripe.customers.*`
- `stripe.subscriptions.*`
- `stripe.invoices.*`
- `stripe.webhooks.*`

### Gereksinimler
- Stripe API Key (Secret Key)
- Webhook Endpoint URL (public)
- Node.js 18+