## Must-b Asana Task Manager

Asana proje ve görevlerini oluşturur, günceller ve takip eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Asana hesabı ve API erişimi
- Must-b Core v1.2+