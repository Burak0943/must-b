## Must-b Browserless API Bridge

Browserless.io headless Chrome API'sine bağlanarak web automation ve screenshot alır.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Browserless hesabı ve API erişimi
- Must-b Core v1.2+