## Must-b GitHub Repo Autopilot

GitHub API ve git CLI üzerinden tam otonom repo yönetimi.

### Özellikler
- **Code Review**: PR diff'lerini analiz eder, test coverage raporlar
- **Auto-PR**: Verilen göreve göre feature branch açar, kod yazar, PR oluşturur
- **CI Status Monitoring**: GitHub Actions workflow sonuçlarını takip eder
- **Issue Triaging**: Issue'ları önceliklendirir ve milestone'lara atar
- **Dependency Audit**: `npm audit` ve `dependabot` çıktılarını işler

### Gereksinimler
- GitHub Personal Access Token (repo + workflow scopes)
- Git 2.40+