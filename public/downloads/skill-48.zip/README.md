## Must-b InfluxDB Time-Series

InfluxDB'ye zaman serisi verisi yazar ve Flux sorguları çalıştırır.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- InfluxDB hesabı ve API erişimi
- Must-b Core v1.2+