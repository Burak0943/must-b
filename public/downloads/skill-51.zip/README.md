## Must-b Sentry Error Tracker

Sentry issue'larını listeler, önceliklendirir ve release ilişkilendirir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Sentry hesabı ve API erişimi
- Must-b Core v1.2+