## Must-b GDPR Compliance Checker

Kodbase ve config'i GDPR uyumluluk açısından tarar ve rapor üretir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Compliance hesabı ve API erişimi
- Must-b Core v1.2+