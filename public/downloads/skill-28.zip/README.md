## Must-b MongoDB Atlas Agent

MongoDB koleksiyonlarını sorgular, indeksler ve aggregation pipeline'ları çalıştırır.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- MongoDB hesabı ve API erişimi
- Must-b Core v1.2+