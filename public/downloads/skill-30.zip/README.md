## Must-b Apache Kafka Producer

Kafka topic'lerine mesaj üretir ve consumer group'larını yönetir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Kafka hesabı ve API erişimi
- Must-b Core v1.2+