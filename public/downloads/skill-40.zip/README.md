## Must-b Airtable Database Bridge

Airtable base ve table'larından veri okur, yazar ve formül hesaplar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Airtable hesabı ve API erişimi
- Must-b Core v1.2+