## Must-b AssemblyAI Audio Analysis

AssemblyAI ile ses transkripsiyon, özetleme ve duygu analizi yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- AssemblyAI hesabı ve API erişimi
- Must-b Core v1.2+