## Must-b Multi-Language Translator

Google Translate ve DeepL API ile metni 100+ dile çevirir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Google hesabı ve API erişimi
- Must-b Core v1.2+