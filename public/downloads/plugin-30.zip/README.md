## Must-b Map & Geo Plotter

Koordinat verilerini harita üzerine işaretler ve statik harita görüntüsü üretir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Geo hesabı ve API erişimi
- Must-b Core v1.2+