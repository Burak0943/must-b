## Must-b PostgreSQL Expert Agent

Natural language ile PostgreSQL veritabanı yönetimi.

### Özellikler
- Text-to-SQL: Doğal dil sorularını güvenli SQL'e çevirir
- EXPLAIN ANALYZE çıktısını yorumlar
- Missing index tespiti ve önerisi
- Schema migration script üretimi
- Read-only mode desteği (production güvenliği için)