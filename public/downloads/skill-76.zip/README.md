## Must-b Meilisearch Agent

Meilisearch instance'ına belge ekler ve full-text arama yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Meilisearch hesabı ve API erişimi
- Must-b Core v1.2+