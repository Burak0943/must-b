## Must-b Box Enterprise Storage

Box klasör ve dosyalarını yönetir, metadata etiketler.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Box hesabı ve API erişimi
- Must-b Core v1.2+