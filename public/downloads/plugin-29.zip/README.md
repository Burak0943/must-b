## Must-b Chart & Graph Maker

Chart.js tabanlı çizgi, çubuk ve pasta grafiklerini SVG/PNG olarak üretir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Native hesabı ve API erişimi
- Must-b Core v1.2+