## Must-b Make Scenario Runner

Make (Integromat) senaryolarını çalıştırır ve veri pipe'lar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Make hesabı ve API erişimi
- Must-b Core v1.2+