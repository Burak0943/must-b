## Must-b LangChain Bridge

LangChain chain ve agent'larını Must-b görev sistemiyle entegre eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- LangChain hesabı ve API erişimi
- Must-b Core v1.2+