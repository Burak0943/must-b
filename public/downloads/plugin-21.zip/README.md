## Must-b Git Operations Manager

Git add, commit, push, merge ve rebase işlemlerini otomatikleştirir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Git hesabı ve API erişimi
- Must-b Core v1.2+