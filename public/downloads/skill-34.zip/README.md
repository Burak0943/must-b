## Must-b HubSpot CRM Sync

HubSpot contact, deal ve company kayıtlarını ajan hafızasıyla senkronize eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- HubSpot hesabı ve API erişimi
- Must-b Core v1.2+