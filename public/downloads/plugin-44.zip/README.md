## Must-b Security Vulnerability Scanner

npm audit ve OWASP ZAP ile bağımlılık ve web güvenlik açıklarını tarar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Security hesabı ve API erişimi
- Must-b Core v1.2+