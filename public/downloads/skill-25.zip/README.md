## Must-b Vercel Deploy Agent

Next.js ve Vite projelerini Vercel'e tek komutla deploy eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Vercel hesabı ve API erişimi
- Must-b Core v1.2+