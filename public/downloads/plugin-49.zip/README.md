## Must-b Proxy & VPN Manager

HTTP/SOCKS5 proxy rotasyonu ve VPN bağlantı yönetimi yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Network hesabı ve API erişimi
- Must-b Core v1.2+