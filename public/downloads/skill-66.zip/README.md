## Must-b Kubernetes Operator

Kubernetes pod, deployment ve service kaynaklarını ajan kontrolüyle yönetir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Kubernetes hesabı ve API erişimi
- Must-b Core v1.2+