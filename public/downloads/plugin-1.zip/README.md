## Must-b Terminal Stream & Control

Sistem terminaline düşük seviyeli erişim sağlayan temel Must-b plugin'i.

### Özellikler
- PTY (Pseudo-Terminal) desteği: vim, htop gibi interaktif programlar çalışır
- Streaming stdout/stderr: Uzun işlemlerde gerçek zamanlı çıktı
- Session management: Birden fazla terminal oturumu paralel yönetilir
- Signal control: SIGINT, SIGTERM, SIGKILL desteği