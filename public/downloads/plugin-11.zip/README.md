## Must-b Email Composer & Sender

SMTP veya API üzerinden zengin HTML e-posta taslaklar ve gönderir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- SMTP hesabı ve API erişimi
- Must-b Core v1.2+