## Must-b Brave Search API

Brave Search bağımsız index'inden gizlilik odaklı web araması yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Brave hesabı ve API erişimi
- Must-b Core v1.2+