## Must-b Microsoft Teams Bridge

Teams kanallarına mesaj gönderir ve Adaptive Card yayınlar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Microsoft hesabı ve API erişimi
- Must-b Core v1.2+