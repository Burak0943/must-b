## Must-b Secret & Password Vault

AES-256 şifreli yerel secret kasası yönetir ve key rotasyonu uygular.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Native hesabı ve API erişimi
- Must-b Core v1.2+