## Must-b Rate Limiter & Throttle

API çağrılarına token bucket ve sliding window rate limiting uygular.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Native hesabı ve API erişimi
- Must-b Core v1.2+