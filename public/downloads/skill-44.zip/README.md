## Must-b Auth0 Identity Manager

Auth0 kullanıcı ve rol yönetimini ajan akışına entegre eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Auth0 hesabı ve API erişimi
- Must-b Core v1.2+