## Must-b PagerDuty Alerting

PagerDuty incident oluşturur, acknowledge eder ve eskalasyon yönetir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- PagerDuty hesabı ve API erişimi
- Must-b Core v1.2+