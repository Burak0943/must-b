## Must-b Linear Dev Ops

Linear GraphQL API üzerinden end-to-end issue ve sprint yönetimi.

### Özellikler
- Issue oluşturma ve atama
- Cycle (sprint) planlama
- Roadmap güncelleme
- GitHub PR — Linear issue senkronizasyonu