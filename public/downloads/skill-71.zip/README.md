## Must-b Mailchimp Campaigns

Mailchimp kampanyaları oluşturur, segment tanımlar ve istatistik çeker.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Mailchimp hesabı ve API erişimi
- Must-b Core v1.2+