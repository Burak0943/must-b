## Must-b Redis Cache Manager

Redis key-value store üzerinde akıllı cache stratejileri uygular.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Redis hesabı ve API erişimi
- Must-b Core v1.2+