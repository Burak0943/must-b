## Must-b Supabase Realtime

Supabase tablolarını gerçek zamanlı dinler ve ajan tetikleyicileri çalıştırır.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Supabase hesabı ve API erişimi
- Must-b Core v1.2+