## Must-b Shopify Commerce Sync

Shopify Admin API ve Storefront API entegrasyonu.

### Özellikler
- Ürün, varyant ve stok yönetimi
- Sipariş akışı takibi
- Otomatik indirim kodu üretimi
- Müşteri segmentasyonu ve email tetikleme