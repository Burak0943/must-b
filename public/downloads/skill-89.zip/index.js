/**
 * Must-b Deepgram Transcription
 * Version : v1.3.0
 * Author  : Must-b Core <core@must-b.com>
 * License : MIT
 *
 * Deepgram Nova-2 ile ses dosyalarını ve canlı stream'leri metne çevirir.
 */

'use strict';

class MustbDeepgramTranscription {
  constructor(config = {}) {
    this.name    = 'Must-b Deepgram Transcription';
    this.version = 'v1.3.0';
    this.config  = config;
    this._ready  = false;
  }

  /** Initialize the integration and validate credentials. */
  async initialize() {
    this._validateConfig();
    this._ready = true;
    console.log(`[Must-b] ${this.name} initialized (v${this.version})`);
    return this;
  }

  /** Execute an agent task object. */
  async execute(task = {}) {
    if (!this._ready) await this.initialize();
    console.log(`[Must-b] ${this.name} executing task: ${task.description ?? 'unnamed'}`);
    return this._run(task);
  }

  /** Override in subclass — perform the actual work. */
  async _run(task) {
    throw new Error('_run() must be implemented by the integration.');
  }

  /** Validate required config keys. */
  _validateConfig() {
    const required = this.constructor.requiredConfig ?? [];
    for (const key of required) {
      if (!this.config[key]) {
        throw new Error(`[Must-b] Missing required config key: ${key}`);
      }
    }
  }

  /** Graceful shutdown. */
  async shutdown() {
    this._ready = false;
    console.log(`[Must-b] ${this.name} shut down.`);
  }

  static get requiredConfig() { return []; }
}

module.exports = { MustbDeepgramTranscription };
