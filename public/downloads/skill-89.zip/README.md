## Must-b Deepgram Transcription

Deepgram Nova-2 ile ses dosyalarını ve canlı stream'leri metne çevirir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Deepgram hesabı ve API erişimi
- Must-b Core v1.2+