## Must-b GitLab CI Manager

GitLab pipeline'larını başlatır ve job artifact'larını indirir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- GitLab hesabı ve API erişimi
- Must-b Core v1.2+