## Must-b Elasticsearch Search

Elasticsearch cluster'ına belge indeksler ve full-text / semantic arama yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Elastic hesabı ve API erişimi
- Must-b Core v1.2+