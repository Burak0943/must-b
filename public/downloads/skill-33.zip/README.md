## Must-b Twilio SMS & Voice

Twilio üzerinden SMS, WhatsApp ve sesli arama gönderir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Twilio hesabı ve API erişimi
- Must-b Core v1.2+