## Must-b Long-Term Memory (LTM)

Must-b'nin en kritik plugin'i. Tüm ajan konuşmalarını ve edinilen bilgileri yapılandırılmış hafızaya alır.

### Özellikler
- Otomatik memory consolidation (önemli bilgileri uzun süreli hafızaya taşır)
- Semantic retrieval (bağlamla en alakalı memories'i çeker)
- Memory decay: Uzun süre kullanılmayan kayıtlar önem skoru düşer
- Privacy: Tüm memories şifreli saklı (AES-256)
- Export/import: Hafıza transferi desteklenir