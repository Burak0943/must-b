## Must-b Weaviate Vector Store

Weaviate GraphQL API üzerinden vektör nesnesi yazar ve sorgular.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Weaviate hesabı ve API erişimi
- Must-b Core v1.2+