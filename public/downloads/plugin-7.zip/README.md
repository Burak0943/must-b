## Must-b Image Generation Engine

DALL-E 3 ve Stable Diffusion ile görev bazlı görsel üretir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- OpenAI hesabı ve API erişimi
- Must-b Core v1.2+