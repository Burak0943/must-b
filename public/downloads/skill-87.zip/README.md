## Must-b Cohere NLP Engine

Cohere Command ve Embed modellerini anlama ve sınıflandırma görevleri için kullanır.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Cohere hesabı ve API erişimi
- Must-b Core v1.2+