## Must-b Firecrawl Web Reader

Firecrawl ile web sitelerini Markdown'a dönüştürür ve crawl eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Firecrawl hesabı ve API erişimi
- Must-b Core v1.2+