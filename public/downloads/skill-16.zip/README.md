## Must-b Obsidian Vault Reader

Obsidian vault'unuzu Must-b'nin uzun süreli hafıza katmanına bağlar.

### Özellikler
- [[wikilink]] graph traversal
- Tag ve frontmatter indexleme
- Incremental sync (sadece değişen notları yeniden indexler)
- Dataview sorgu desteği