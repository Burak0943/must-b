## Must-b Anthropic Claude Bridge

Claude 3.5 Sonnet ve Claude 3 Haiku modellerini Must-b pipeline'ına entegre eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Anthropic hesabı ve API erişimi
- Must-b Core v1.2+