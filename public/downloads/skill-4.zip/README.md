## Must-b Datadog Observability

Must-b ajanlarının tüm operasyonel metriklerini, yapılandırılmış loglarını ve dağıtık trace'lerini Datadog platformuna aktarır.

### Özellikler
- **Custom Metrics**: Ajan başarı oranı, görev süreleri, tool call sayıları
- **Structured Logging**: JSON formatında log shipper (loglar Datadog Log Management'a akar)
- **APM Tracing**: Her ajan görevini Datadog APM span olarak raporlar
- **Anomaly Detection**: Hata oranı spike'larında otomatik Datadog Monitor tetiklenebilir
- **Dashboard Template**: Hazır Must-b Datadog dashboard JSON'u dahil

### Metrik Listesi
- `mustb.task.duration_ms` (histogram)
- `mustb.task.success_rate` (gauge)
- `mustb.llm.token_usage` (counter)
- `mustb.tool.call_count` (counter)