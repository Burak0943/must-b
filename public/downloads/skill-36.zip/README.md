## Must-b Zendesk Support Agent

Zendesk ticket'larını okur, yanıtlar ve önceliklendirir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Zendesk hesabı ve API erişimi
- Must-b Core v1.2+