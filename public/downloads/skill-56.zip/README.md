## Must-b CloudWatch Monitor

AWS CloudWatch alarm ve metric'lerini izler, kritik durumlarda aksiyon alır.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- AWS hesabı ve API erişimi
- Must-b Core v1.2+