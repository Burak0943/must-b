## Must-b Grafana Dashboard Agent

Grafana dashboard'larını oluşturur, panel ekler ve alert kurar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Grafana hesabı ve API erişimi
- Must-b Core v1.2+