## Must-b Qdrant Vector DB

Qdrant collection'larına point ekler ve filtered vector search yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Qdrant hesabı ve API erişimi
- Must-b Core v1.2+