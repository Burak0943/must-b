## Must-b Figma to Tailwind Exporter

Figma REST API üzerinden tasarım token'larını ve bileşenlerini kod'a çevirir.

### Özellikler
- Frame → React Component dönüşümü
- Design token extraction (renkler, tipografi, spacing)
- Tailwind class mapping
- Responsive variant üretimi