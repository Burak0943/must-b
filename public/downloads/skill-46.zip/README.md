## Must-b PlanetScale DB Agent

PlanetScale serverless MySQL veritabanına bağlanır ve migration uygular.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- PlanetScale hesabı ve API erişimi
- Must-b Core v1.2+