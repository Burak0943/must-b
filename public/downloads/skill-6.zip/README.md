## Must-b Slack Enterprise Bridge

Slack workspace'inizdeki konuşmaları gerçek zamanlı izler ve yapılandırılmış iş akışlarını tetikler.

### Özellikler
- **Mention Listener**: Ajan, @mustb mention'larına otomatik yanıt verir
- **Thread Summarizer**: Uzun thread'leri özetleyerek digest gönderir
- **Jira Auto-Ticket**: `!ticket` komutuyla thread içeriğinden Jira issue üretir
- **Scheduled Reports**: Günlük/haftalık kanal özetleri belirlenmiş saatte paylaşır