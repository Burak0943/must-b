## Must-b Audio Transcription Core

OpenAI Whisper ile yerel ses dosyalarını metne dönüştürür.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Whisper hesabı ve API erişimi
- Must-b Core v1.2+