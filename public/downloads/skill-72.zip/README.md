## Must-b Dropbox File Manager

Dropbox hesabında dosya yükler, indirir ve paylaşım linki üretir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Dropbox hesabı ve API erişimi
- Must-b Core v1.2+