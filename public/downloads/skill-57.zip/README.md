## Must-b New Relic APM

New Relic trace ve metric verilerini işler, performans anomalilerini raporlar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- New Relic hesabı ve API erişimi
- Must-b Core v1.2+