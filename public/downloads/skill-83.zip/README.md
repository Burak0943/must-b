## Must-b Replicate AI Runner

Replicate model'larını API üzerinden çalıştırır ve output'larını işler.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Replicate hesabı ve API erişimi
- Must-b Core v1.2+