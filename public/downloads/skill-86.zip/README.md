## Must-b Mistral AI Connector

Mistral Large ve Codestral modellerini Must-b görev akışına entegre eder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Mistral hesabı ve API erişimi
- Must-b Core v1.2+