## Must-b Prometheus Metrics

Prometheus metriklerini push gateway üzerinden kaydeder ve PromQL sorgular.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Prometheus hesabı ve API erişimi
- Must-b Core v1.2+