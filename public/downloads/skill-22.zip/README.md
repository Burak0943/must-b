## Must-b Pinecone Vector Store

Pinecone vektör veritabanına embedding yazar ve semantic arama yapar.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Pinecone hesabı ve API erişimi
- Must-b Core v1.2+