## Must-b Redis Cache Plugin

Must-b sonuçlarını Redis'e cache'ler, TTL ve invalidation yönetir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Redis hesabı ve API erişimi
- Must-b Core v1.2+