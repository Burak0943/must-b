## Must-b Telegram Command Center

Telegram Bot API üzerinden Must-b'ye uzaktan erişim.

### Komutlar
- `/status` — Ajan durumunu ve son görevleri raporlar
- `/run [görev]` — Yeni görev başlatır
- `/logs` — Son 10 log satırını gönderir
- `/alert on|off` — Hata alertlerini açar/kapatır