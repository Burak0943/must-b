## Must-b Perplexity AI Query

Perplexity sonar modelini kullanarak gerçek zamanlı kaynaklı cevaplar üretir.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Perplexity hesabı ve API erişimi
- Must-b Core v1.2+