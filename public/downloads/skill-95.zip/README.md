## Must-b Exa Neural Search

Exa semantic web arama API'si ile içerik keşfeder.

### Özellikler
- Tam Must-b Core entegrasyonu
- Otomatik yeniden bağlanma ve hata yönetimi
- Yapılandırılmış JSON loglama
- Async/await tabanlı non-blocking API

### Gereksinimler
- Node.js 18+
- Exa hesabı ve API erişimi
- Must-b Core v1.2+