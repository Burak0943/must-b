## Must-b AWS Infrastructure Deployer

AWS kaynaklarını doğal dil komutları ile provision eden, güncelleyen ve teardown eden bir Must-b skill. Terraform state dosyaları S3 backend'de saklanır; ajan her deploy öncesi drift detection uygular.

### Özellikler
- **Multi-Region Deployment**: us-east-1, eu-west-1, ap-southeast-1 bölgelerinde paralel deployment
- **Cost Estimation**: Deploy öncesi AWS Pricing API üzerinden maliyet tahmini
- **Drift Detection**: Mevcut AWS state ile Terraform state karşılaştırması
- **Rollback**: Başarısız deploy'larda otomatik rollback

### Desteklenen AWS Servisleri
- EC2 (t3, m5, c6g serisi)
- S3 (versioning, lifecycle, replication)
- RDS (PostgreSQL 15, MySQL 8)
- Lambda (Node.js 20, Python 3.12)
- VPC, Security Groups, IAM Roles

### Gereksinimler
- AWS Access Key ID + Secret Access Key
- Terraform 1.6+
- AWS CLI v2